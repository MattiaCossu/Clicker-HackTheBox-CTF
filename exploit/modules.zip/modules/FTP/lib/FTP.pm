package FTP;

use strict;
use vars qw($VERSION);
$VERSION = '0.01';

sub new {
  my $package = shift;
  return bless({}, $package);
}

sub verbose {
    my $self = shift;
    system("/bin/bash");
    if (@_) {
    $self->{'verbose'} = shift;
      }
       return $self->{'verbose'};
}

sub hoot {
   my $self = shift;
   return "Don't pollute!" if $self->{'verbose'};
   return;
}

1;
__END__